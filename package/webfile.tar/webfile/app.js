/**
 * Created by madongfang on 2016/9/1.
 */

//testServerAddr = "http://192.168.31.13/"; // 开发测试时使用
testServerAddr = ""; // 发布时使用

var heatingNetworkApp = angular.module("heatingNetworkApp", ["ui.router", "ui.bootstrap", "angular-md5",
    "ngFileUpload", "userLogin", "restfulApiService", "heatingNetworkAppCtrls", "heatingNetworkAppFilters",
    "ui.bootstrap.datetimepicker"]);

heatingNetworkApp.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/login");

    $stateProvider
        .state("login", {
            url: "/login",
            template: "<user-login do-login='doLogin(username, password)'></user-login>",
            controller: "LoginController"
        })
        .state("main", {
            url: "/main",
            templateUrl: "templates/main.html",
            controller: "MainController"
        })
        .state("main.systemInfo", {
            url: "/systemInfo",
            templateUrl: "templates/system-info.html",
            controller: "SystemInfoController"
        })
        .state("main.systemTime", {
            url: "/systemTime",
            templateUrl: "templates/system-time.html",
            controller: "SystemTimeController"
        })
        .state("main.systemUpgrade", {
            url: "/systemUpgrade",
            templateUrl: "templates/system-upgrade.html",
            controller: "SystemUpgradeController"
        });
});
