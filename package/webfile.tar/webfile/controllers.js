/**
 * Created by madongfang on 2016/9/1.
 */

heatingNetworkAppCtrls = angular.module("heatingNetworkAppCtrls", []);

heatingNetworkAppCtrls.controller("LoginController", ["$scope", "md5", "ApiSystemLogin", "$state",
    function ($scope, md5, ApiSystemLogin, $state) {
        $scope.doLogin = function (username, password) {
            ApiSystemLogin.exec({username: username, password: md5.createHash(password)},
                function (response) {
                    $state.go("main.systemInfo");
                },
                function (response) {
                    alert(response.data.error);
                }
            );
        };
    }
]);

heatingNetworkAppCtrls.controller("MainController", ["$scope", "$state", "ApiSystemLogout",
    function ($scope, $state, ApiSystemLogout) {
        $scope.doLogout = function () {
            ApiSystemLogout.exec();
        }
    }
]);

heatingNetworkAppCtrls.controller("SystemInfoController", ["$scope", "ApiSystemInfo",
    function ($scope, ApiSystemInfo) {
        $scope.systemInfo = ApiSystemInfo.get(
            function () {
            },
            function (response) {
                alert(response.data.error);
            }
        );
    }
]);

heatingNetworkAppCtrls.controller("SystemTimeController", ["$scope", "ApiSystemTime", "$interval", "dateFilter",
    function ($scope, ApiSystemTime, $interval, dateFilter) {
        var timeNow = ApiSystemTime.get(
            function ()
            {
                $scope.deviceTimeNow = new Date(timeNow.utcTime);
                var timeoutId = $interval(function () {
                    $scope.deviceTimeNow.setTime($scope.deviceTimeNow.getTime() + 1000);
                }, 1000);

                $scope.$on("$destroy", function () {
                    $interval.cancel(timeoutId);
                });
            },
            function (response) {
                alert(response.data.error);
            });

        $scope.setTime = new Date();
        $scope.$watch("setTime", function (newValue, oldValue, scope) {
            if ($scope.setTime instanceof Date)
            {
                $scope.setTimeString = dateFilter($scope.setTime, "yyyy-MM-dd HH:mm:ss");
            }
        });

        $scope.setSystemTime = function () {
            var momentSetTime = moment($scope.setTimeString, "YYYY-MM-DD HH:mm:ss");
            ApiSystemTime.update({utcTime:momentSetTime.toISOString()}, function () {
                $scope.deviceTimeNow = new Date(momentSetTime.toISOString());
            }, function (response) {
                alert(response.data.error);
            });
        };
    }
]);

heatingNetworkAppCtrls.controller("SystemUpgradeController", ["$scope", "Upload", "ApiSystemReboot",
    function ($scope, Upload, ApiSystemReboot) {
        $scope.firmware = null;

        $scope.doUpgrade = function () {
            if (!($scope.firmware instanceof File))
            {
                alert("请选择升级文件");
                return;
            }

            Upload.http({
                url: testServerAddr + "/api/system/upgrade",
                headers : {
                    "Content-Type": $scope.firmware.type
                },
                data: $scope.firmware,
                withCredentials: true
            }).then(function (response) {
                    alert("升级成功，请重启设备");
                }, function (response) {
                    alert("升级失败：" + response.data.error);
                }
            );
        };

        $scope.doReboot = function () {
            ApiSystemReboot.exec(function () {
                // alert("重启成功");
            }, function (response) {
                if (response.data.error)
                {
                    alert(response.data.error);
                }
            });
        };
    }
]);