heatingNetworkAppFilters = angular.module("heatingNetworkAppFilters", []);
